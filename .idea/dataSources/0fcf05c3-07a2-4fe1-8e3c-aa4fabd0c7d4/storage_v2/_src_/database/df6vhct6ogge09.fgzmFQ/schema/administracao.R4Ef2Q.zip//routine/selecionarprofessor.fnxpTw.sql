create function selecionarprofessor(pfiltro character varying, plinhas integer, ppagina integer)
    returns TABLE("totalLinhas" bigint, id integer, nome character varying, sobrenome character varying, cpf character)
language plpgsql
as $$
/*
 SELECT * FROM Administracao.SelecionarProfessor('', 10, 1);
*/

BEGIN
    RETURN QUERY
    SELECT
        COUNT(1)
        OVER (
            PARTITION BY 1 ),
        p.id,
        p.nome,
        p.sobrenome,
        p.cpf
    FROM Administracao.professor p
    WHERE
        CASE WHEN pFiltro IS NOT NULL
            THEN p.nome ILIKE '%' || pFiltro || '%' OR p.sobrenome ILIKE '%' || pFiltro || '%'
        ELSE
            TRUE
        END
    LIMIT
        CASE WHEN pLinhas > 0 AND pPagina > 0
            THEN pLinhas
        ELSE
            NULL
        END
    OFFSET
        CASE WHEN pLinhas > 0 AND pPagina > 0
            THEN (pPagina - 1) * pLinhas
        ELSE
            NULL
        END;
END;
$$;

