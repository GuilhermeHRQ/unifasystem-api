create function selecionarprofessorporid(pid integer)
    returns TABLE(id integer, cpf character, nome character varying, sobrenome character varying, "dataNascimento" date, salario numeric, email character varying, telefone character, logon character varying, "idTipoUsuario" integer, "ultimoLogin" timestamp without time zone, endereco json)
language plpgsql
as $$
/*
    SELECT * FROM Administracao.SelecionarProfessorPorId(1);
*/

BEGIN
    RETURN QUERY
    SELECT
        p.id,
        p.cpf,
        p.nome,
        p.sobrenome,
        p.dataNascimento,
        p.salario,
        p.email,
        p.telefone,
        ua.logon,
        ua.idTipoUsuario,
        ua.ultimoLogin,
        (
            SELECT COALESCE(json_agg(enderecoJson), '[]')
            FROM (
                     SELECT
                         pe.id          "id",
                         pe.cep         "cep",
                         pe.idCidade    "idCidade",
                         pe.logradouro  "logradouro",
                         pe.numero      "numero",
                         pe.bairro      "bairro",
                         pe.complemento "complemento"
                     FROM Administracao.endereco pe
                     WHERE pe.id = p.idEndereco
                 ) enderecoJson
        ) endereco
    FROM Administracao.professor p
        INNER JOIN Seguranca.usuarioAcesso ua ON (ua.idUsuario = p.id)
    WHERE p.id = pId;
END;
$$;

