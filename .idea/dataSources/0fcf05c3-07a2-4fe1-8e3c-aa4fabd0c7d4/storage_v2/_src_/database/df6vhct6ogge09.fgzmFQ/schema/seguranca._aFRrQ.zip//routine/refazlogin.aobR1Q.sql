create function refazlogin(pidusuarioacesso integer)
    returns TABLE("idUsuario" integer, "idUsuarioAcesso" integer, "idTipoUsuario" integer, nome character varying, logon character varying, ativo boolean, opcoes json)
language plpgsql
as $$
-- SELECT * FROM seguranca.RefazLogin(1);

BEGIN
    RETURN QUERY
    SELECT
        ua.idusuario,
        ua.id,
        ua.idtipousuario,
        ua.nome,
        ua.logon,
        ua.ativo,
        (SELECT CASE
                WHEN json_agg(opcoesJson) IS NULL
                    THEN '[]'
                ELSE json_agg(opcoesJson) END
         FROM (SELECT
                   opm.id,
                   opm.idmae,
                   opm.url,
                   opm.nome
               FROM Seguranca.opcaomenuacesso opma
                   INNER JOIN Seguranca.opcaomenu opm ON (opma.idopcaomenu = opm.id)
               WHERE opma.idtipousuario = ua.idtipousuario
               ORDER BY opm.nome) opcoesJson) opcoes
    FROM seguranca.usuarioacesso ua
    WHERE ua.id = pIdUsuarioAcesso;
END;
$$;

