create function refazlogin(pidusuarioacesso integer)
    returns TABLE("idUsuario" integer, "idUsuarioAcesso" integer, "idTipoUsuario" integer, nome character varying, logon character varying)
language plpgsql
as $$
-- SELECT * FROM seguranca.RefazLogin(1);

BEGIN
    RETURN QUERY
    SELECT
        ua.idusuario,
        ua.id,
        ua.idtipousuario,
        ua.nome,
        ua.logon
    FROM seguranca.usuarioacesso ua
    WHERE ua.id = pIdUsuarioAcesso;
END;
$$;

