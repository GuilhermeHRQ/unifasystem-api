create function loginusuario(plogin character varying, psenha character varying)
    returns TABLE("idUsuario" integer, "idUsuarioAcesso" integer, "idTipoUsuario" integer, nome character varying, email character varying, logon character varying, ativo boolean, "senhaCorreta" boolean)
language plpgsql
as $$
/*
SELECT *
FROM seguranca.LoginUsuario(
        'teste',
        ''
);
*/

BEGIN

    RETURN QUERY
    SELECT
        a.id,
        ua.id,
        ua.idtipousuario,
        a.nome,
        a.email,
        ua.logon,
        ua.ativo,
        (md5(pSenha) = ua.senha)
    FROM seguranca.usuarioacesso ua
        INNER JOIN seguranca.administrador a on ua.id = a.idusuarioacesso
    WHERE ua.logon = pLogin;
END;
$$;

