create function loginusuario(plogin character varying, psenha character varying)
    returns TABLE("idUsuario" integer, "idUsuarioAcesso" integer, "idTipoUsuario" integer, nome character varying, logon character varying, ativo boolean, "senhaCorreta" boolean, opcoes json)
language plpgsql
as $$
/*
SELECT *
FROM seguranca.LoginUsuario(
        'admin',
        'teste123'
);
*/

BEGIN

    RETURN QUERY
    SELECT
        ua.idusuario,
        ua.id,
        ua.idtipousuario,
        ua.nome,
        ua.logon,
        ua.ativo,
        (ua.senha = md5(pSenha)),
        (CASE WHEN (ua.senha = md5(pSenha))
            THEN (SELECT CASE
                         WHEN json_agg(opcoesJson) IS NULL
                             THEN '[]'
                         ELSE json_agg(opcoesJson) END
                  FROM (SELECT
                            opm.id,
                            opm.idmae,
                            opm.url,
                            opm.nome
                        FROM Seguranca.opcaomenuacesso opma
                            INNER JOIN Seguranca.opcaomenu opm ON (opma.idopcaomenu = opm.id)
                        WHERE opma.idtipousuario = ua.idtipousuario
                        ORDER BY opm.nome) opcoesJson)
         ELSE
             '[]'
         END) opcoes
    FROM seguranca.usuarioacesso ua
    WHERE ua.logon = pLogin;
END;
$$;

