create function loginusuario(plogin character varying, psenha character varying)
    returns TABLE("idUsuario" integer, "idUsuarioAcesso" integer, "idTipoUsuario" integer, nome character varying, logon character varying, ativo boolean, "senhaCorreta" boolean)
language plpgsql
as $$
/*
SELECT *
FROM seguranca.LoginUsuario(
        'teste',
        ''
);
*/

BEGIN

    RETURN QUERY
    SELECT
        ua.idusuario,
        ua.id,
        ua.idtipousuario,
        ua.nome,
        ua.logon,
        ua.ativo,
        (ua.senha = md5(pSenha))
    FROM seguranca.usuarioacesso ua
    WHERE ua.logon = pLogin;
END;
$$;

