create function inserirprofessor(pcpf character, pnome character varying, psobrenome character varying, pdatanascimento date, psalario numeric, pemail character varying, ptelefone character, plogon character varying, psenha character varying, pendereco json)
    returns json
language plpgsql
as $$
/*

SELECT * FROM Administracao.InserirProfessor(
    '46114968809',
    'Jamal',
    'Oliveira',
    '1999-02-12',
    1000.00,
    'jamal@a.com',
    '16992417883',
    'jamal',
    'teste123',
    '[
        {
            "cep": "14409013",
            "idCidade": 1,
            "logradouro": "Rua Jose Oliva",
            "numero": "33",
            "bairro": "Batatao",
            "complemento": "Iparitondgqa esquerda"
        }
    ]' ::JSON
);

*/

DECLARE
    vIdEndereco  INTEGER;
    vIdProfessor INTEGER;
BEGIN

    INSERT INTO Administracao.endereco (
        cep,
        idCidade,
        logradouro,
        numero,
        bairro,
        complemento
    )
        SELECT
            "cep",
            "idCidade",
            "logradouro",
            "numero",
            "bairro",
            "complemento"
        FROM json_to_recordset(pEndereco)
            AS x(
             "cep" CHAR(8),
             "idCidade" INTEGER,
             "logradouro" VARCHAR,
             "numero" VARCHAR,
             "bairro" VARCHAR,
             "complemento" VARCHAR
             )
    RETURNING id
        INTO vIdEndereco;


    INSERT INTO Administracao.professor (
        cpf,
        nome,
        sobrenome,
        dataNascimento,
        salario,
        email,
        telefone,
        idEndereco
    ) VALUES (
        pCpf,
        pNome,
        pSobrenome,
        pDataNascimento,
        pSalario,
        pEmail,
        pTelefone,
        vIdEndereco
    )
    RETURNING id
        INTO vIdProfessor;

    INSERT INTO Seguranca.usuarioAcesso (
        idusuario,
        idtipousuario,
        nome,
        logon,
        senha
    ) VALUES (
        vIdProfessor,
        2, -- Professor
        pNome,
        pLogon,
        md5(pSenha)
    );

    RETURN json_build_object(
            'executionCode', 0,
            'message', 'Professor inserido com sucesso',
            'content', json_build_object(
                    'id', vIdProfessor
            )
    );
END;
$$;

